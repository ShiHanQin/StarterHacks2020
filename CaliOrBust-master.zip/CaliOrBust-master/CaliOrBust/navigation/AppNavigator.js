import React from 'react';
import { createAppContainer, createSwitchNavigator } from 'react-navigation';

import MainStack from './MainStack';

export default createAppContainer(MainStack);
